# TYTiedRender
分段加载超大图片，支持缩放
